import type { BinaryNode } from '../types';
export declare const encodeBinaryNodeLegacy: (node: BinaryNode) => any;
export declare const decodeBinaryNodeLegacy: (data: Buffer, indexRef: {
    index: number;
}) => BinaryNode;
